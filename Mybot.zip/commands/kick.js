const discord = require("discord.js");
const config = require('../config.json');

module.exports.run = async (bot, message, args) => {
    let target = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));
    let reason = args.slice(1).join(' ');
    let logs = message.guild.channels.find('name', config.logsChannel);
	let user = message.mentions.users.first();
	message.delete()
		.then(msg => msg.delete(20000));
message.delete()
    if (!target) return message.channel.send(`${message.author} :thinking: | Indique um membro.`)
		.then(msg => msg.delete(20000));
    if (!reason) return message.channel.send(`${message.author} :thinking: | Indique um motivo.`)
		.then(msg => msg.delete(20000));
    if (!logs) return message.channel.send(`${message.author} por favor crie um canal ${config.logsChannel} para registrar quem foi expulso!`)
		.then(msg => msg.delete(20000));
	message.delete()
	if (!message.guild.member(user).kickable) return message.channel.send(`${message.author} :cry: | Desculpe, o membro em questão tem um cargo superior ao meu.`)
		.then(msg => msg.delete(20000));
message.guild.member(user).kick()
		


	
	
	message.delete()
    
    let embed = new discord.RichEmbed()
	.setTitle(":pushpin: - Usuário expulso:") 
	.setDescription("O usuário foi punido por falhar com as regras do grupo.")
	.setThumbnail(target.user.avatarURL)
	.setColor(11543845)
	.addField("Tag do Usuário:", target.user.tag, true)
	.addField("ID do Usuário:", `${target.user.id}`, true)
	.addField("Quem puniu:", message.author.tag, true)
	.addField("Motivo:", reason, true)
	.setTimestamp()
	.setFooter('-', bot.user.displayAvatarURL)
    message.channel.send(`${message.author} :thumbsup: | Usuário expulso com sucesso!`)
	.then(msg => msg.delete(20000));
    target.kick(reason);
    logs.send(embed);

};

module.exports.help = {
    name: 'expulsar'
};